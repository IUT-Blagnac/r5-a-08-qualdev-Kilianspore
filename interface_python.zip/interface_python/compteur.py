import tkinter as tk

class StartPage(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Compteur")
        self.counter = 0
        self.label = tk.Label(self, text=f"Compteur : {self.counter}")
        self.label.pack()

        btn_augmenter = tk.Button(self, text="Augmenter", command=self.increment)
        btn_augmenter.pack()

        btn_reduire = tk.Button(self, text="Réduire", command=self.decrement)
        btn_reduire.pack()

    def increment(self):
        self.counter += 1
        self.label.config(text=f"Compteur : {self.counter}")

    def decrement(self):
        self.counter -= 1
        self.label.config(text=f"Compteur : {self.counter}")

if __name__ == "__main__":
    app = StartPage()
    app.mainloop()
