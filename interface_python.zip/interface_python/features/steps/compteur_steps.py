from behave import given, when, then
import tkinter as tk
from compteur import StartPage

@given("l'application est lancée")
def step_given_application_launched(context):
    context.app = StartPage()
    context.app.update()

@when('je clique sur "{button_text}"')
def step_when_click_button(context, button_text):
    for child in context.app.winfo_children():
        if isinstance(child, tk.Button) and child.cget("text") == button_text:
            child.invoke()  # Simule un clic
            return
    raise Exception(f"Bouton {button_text} non trouvé")

@then('le compteur doit afficher "{expected_text}"')
def step_then_verify_counter(context, expected_text):
    label_text = context.app.label.cget("text")
    assert label_text == expected_text, f"Attendu: {expected_text}, obtenu: {label_text}"
